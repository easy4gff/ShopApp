import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { Store } from 'redux';
import { CommonModule } from '@angular/common';
import { DataListModule, PanelModule } from 'primeng/primeng';
import { ButtonModule, FileUploadModule } from 'primeng/primeng';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HttpClient } from '@angular/common/http';

import { AppComponent } from './app.component';
import { ProductsComponent } from './app-products/products.component';
import { appStoreProviders } from './app.store';
import { ProductsState, ProductsReducer } from './product/products.reducer';
import { AppProductComponent } from './app-product/app-product.component';
import { AppAddproductComponent } from './app-addproduct/app-addproduct.component';
import { serverUrlProviders } from './app.props';
import { AppHttpServiceComponent } from './app-http-service/app-http-service.component';

@NgModule({
  declarations: [
    AppComponent,
    ProductsComponent,
    AppProductComponent,
    AppAddproductComponent,
    AppHttpServiceComponent,
  ],
  imports: [
    BrowserModule,
    DataListModule,
    FormsModule,
    ReactiveFormsModule,
    ButtonModule,
    PanelModule,
    BrowserAnimationsModule,
    FileUploadModule,
    HttpClientModule
  ],
  providers: [
    appStoreProviders,
    serverUrlProviders,
    AppHttpServiceComponent
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }

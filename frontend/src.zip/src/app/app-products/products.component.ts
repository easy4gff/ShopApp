import { 
  Component,
  OnInit, 
  Inject,
  ViewEncapsulation 
} from '@angular/core';
import { AppStore } from '../app.store';

import { Product } from '../product/product.model';
import { HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { AppHttpServiceComponent } from '../app-http-service/app-http-service.component';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class ProductsComponent implements OnInit {
  private selectedProduct: Product;
  private products: Product[];

  constructor( private http: HttpClient, private productsService: AppHttpServiceComponent) {
    this.products = this.productsService.refreshProducts();
  }

  ngOnInit() {
    this.products = this.productsService.refreshProducts();
    console.log(this.products);
  }

  addProduct(p: Product) {
    
  }

  deleteProduct(product: Product): void {
    this.productsService.deleteProduct(product.id);
    this.products = this.productsService.refreshProducts();
  }

  // Вот это вот всё я украл :(
//   getImage(imageUrl: string): Observable<File> {
//     return this.http
//         .get(imageUrl, { responseType: ResponseContentType.Blob })
//         .map((res: Response) => res.blob());
//   }

//   imageToShow: any;
  
//   createImageFromBlob(image: Blob) {
//          let reader = new FileReader();
//          reader.addEventListener("load", () => {
//             this.imageToShow = reader.result;
//          }, false);
  
//          if (image) {
//             reader.readAsDataURL(image);
//          }
//   }

//   getImageFromService() {
//     //this.isImageLoading = true;
//     this.getImage(`${SERVER_URL}/image`).subscribe(data => {
//       this.createImageFromBlob(data);
//       //this.isImageLoading = false;
//     }, error => {
//       //this.isImageLoading = false;
//       console.log(error);
//     });
// }
}

export class Product {
    id: number;
    price: number;
    title: string;
    imageSrc: string;
    image: File;

    constructor(id: number, price: number, title: string, /*imageSrc: string*/ image: File) {
        this.id = id;
        this.price = price;
        this.title = title;
        //this.imageSrc = imageSrc;
        this.image = image;
    }
}
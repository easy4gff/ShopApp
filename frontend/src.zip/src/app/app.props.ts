export const SERVER_URL: string = "http://localhost:8080/";

export let serverUrlProviders = { provide: SERVER_URL, useValue: SERVER_URL };
import { Component, OnInit, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Product } from '../product/product.model';
import { SERVER_URL } from '../app.props';

@Component({
  selector: 'app-http-service',
  templateUrl: './app-http-service.component.html',
  styleUrls: ['./app-http-service.component.css']
})
@Injectable()
export class AppHttpServiceComponent implements OnInit {

  constructor(private http: HttpClient) {
  
  }

  refreshProducts(): Product[] {
    let products: Product[] = [];
    this.http.get('http://localhost:8080/products')
    .subscribe(
      (data: Object[]) => {
        console.log(data);
        products = data.map((obj: Product) => new Product(obj.id, obj.price, obj.title, obj.image));
        console.log(products);
      },
      (error: any) => console.log(error)
    );
    return products;
  }

  addProduct(product: Product): void {
    this.http.post(`${SERVER_URL}/products/add`, product)
             .subscribe(
               (status: boolean) => {
                  console.log(status);
               },
               (err) => {
                 console.log(err);
               }
             );
  }

  deleteProduct(id: number): void {
    this.http.delete(`${SERVER_URL}/products?id=${id}`)
                .subscribe((status: boolean) => { 
                console.log(status);
                this.refreshProducts();
                });
    this.refreshProducts();
  }

  ngOnInit() {
  }

}

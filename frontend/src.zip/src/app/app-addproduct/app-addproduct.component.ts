import { 
  Component, 
  OnInit, 
  Inject,
  Output,
  EventEmitter
} from '@angular/core';
import { Store } from 'redux';
import { ProductsState } from '../product/products.reducer';
import { AppStore } from '../app.store';
import { 
  FormBuilder, 
  FormGroup,
  Validators
} from '@angular/forms';
import { addProduct } from '../product/product.actions';
import { Product } from '../product/product.model';

@Component({
  selector: 'app-addproduct',
  templateUrl: './app-addproduct.component.html',
  styleUrls: ['./app-addproduct.component.css']
})
export class AppAddproductComponent implements OnInit {
  private formVisible: boolean = false;
  private form: FormGroup;
  @Output() add: EventEmitter<Product>;

  constructor(/*@Inject(AppStore) private store: Store<ProductsState>,*/ fb: FormBuilder) {
    this.form = fb.group({
      'title': ['', Validators.required],
      'price': ['', Validators.required]
      //'image-src': ['']
    });
    this.add = new EventEmitter<Product>();
  }

  ngOnInit() {
  }

  toggleFormVisibility() : void {
    this.formVisible = this.formVisible ? false : true;
  }

  addProduct(): void {
    let product = new Product(
      543526235,
      this.form.controls['title'].value,
      this.form.controls['price'].value,
      null//this.form.controls['image-src'].value
    );
    this.add.emit(product);
  }

}

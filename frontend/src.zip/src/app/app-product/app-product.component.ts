import { 
  Component, 
  OnInit, 
  Input,
  Output,
  ViewEncapsulation,
  EventEmitter
} from '@angular/core';

import { Product } from '../product/product.model';

import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-product',
  templateUrl: './app-product.component.html',
  styleUrls: ['./app-product.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class AppProductComponent implements OnInit {
  @Input() product: Product;
  @Output() delete: EventEmitter<Product>;

  constructor() { 
    this.delete = new EventEmitter<Product>()
  }

  ngOnInit() {
  }

  emitDeleteEvent(): void {
    this.delete.emit(this.product);
  }
}
